## Run all the code cells in SNA.ipynb in order except for the last code cell
## Use the last code cell only if you have set val_size and test_size to some value.